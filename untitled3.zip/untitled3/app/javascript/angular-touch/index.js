require('./angular-touch');
module.exports = 'ngTouch';
